# Auto Scaling VMSS Screenshots

Please the required screenshots for Auto Scaling VMSS in this directory.
