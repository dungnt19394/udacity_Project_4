# Application Insights Screenshots

Please the required screenshots for Application Insights in this directory.
